function obtenerDatos()
{
    $.get( "http://localhost/apibackend/public/obtenerArtistas", function( data ) {
        $("#datos").empty();
        data.forEach(element => {
            $("#datos").append('<li><a href="#detalle" class="ui-btn ui-btn-icon-right ui-icon-carat-r" onclick="getArtista('+element.id+')">'+element.nombre+'</a></li>');
        });
      });
}

function getArtista(id)
{
    $("#genero").empty();
    $("#nombre_artista").empty();
    $.get("http://localhost/backend/public/artista/"+id,
    function(data, status){
        $("#genero").append('<img src="'+data.genero+'" width="100%">');
        $("#nombre_artista").append('<h3>'+data.nombre+'</h3>');
    });
}